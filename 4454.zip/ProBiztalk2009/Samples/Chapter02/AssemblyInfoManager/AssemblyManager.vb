Namespace ABC.FulFillment.Common
	Public Class AssemblyInfoManager
		Public Const Company As String = "ABC Company"
		Public Const ProductName As String = "FulFillment Application"
		Public Const Copyright As String = "Copyright (c) 2006 ABC Inc."
		Public Const Trademark As String = ""
		Public Const MajorVersion As String = "1"
		Public Const MinorVersion As String = "01"
		Public Const BuildNumber As String = "1"
		Public Const RevisionNumber As String = "35"
	End Class
End Namespace