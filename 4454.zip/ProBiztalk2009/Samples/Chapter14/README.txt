/*******************************************************************************

Chapter 14 - Pro Biztalk 2009 Demo Code. 

// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.

/*******************************************************************************


In the CICSDEMO directory you will find three dub-directories with the following:

-BTSCICSDEMO.- BizTalk project that exposes Transaction Integrator (TI) schema.
-CICSDEMO.- Session Integrator Demo. It uses SNA and TN3270.
-GTEMPINF.- Transaction Integrator project.

/*******************************************************************************