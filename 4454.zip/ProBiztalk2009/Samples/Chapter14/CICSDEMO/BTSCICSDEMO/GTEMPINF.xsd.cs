namespace BTSCICSDEMO {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"GTEMPINF__GetEmployeeInfo__GetEmpInfo__Request", @"GTEMPINF__GetEmployeeInfo__GetEmpInfo__Response"})]
    public sealed class GTEMPINF : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://microsoft.com/HostApplications/TI/WIP"" elementFormDefault=""qualified"" targetNamespace=""http://microsoft.com/HostApplications/TI/WIP"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""GTEMPINF__GetEmployeeInfo__GetEmpInfo__Request"" nillable=""true"" type=""TypeGetEmpInfoRequest"" />
  <xs:element name=""GTEMPINF__GetEmployeeInfo__GetEmpInfo__Response"" nillable=""true"" type=""TypeGetEmpInfoResponse"" />
  <xs:complexType name=""TypeGetEmpInfoRequest"">
    <xs:sequence>
      <xs:element name=""GetEmpInfoInDocument"">
        <xs:complexType>
          <xs:sequence>
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""CODEMP"" type=""xs:string"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_FNAME"" type=""xs:string"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_LNAME"" type=""xs:string"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_FULLNAME"" type=""xs:string"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_DNI"" type=""xs:string"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_STAT"" type=""xs:string"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_REQ"" type=""xs:decimal"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_CONTRIB_LAST2"" type=""xs:decimal"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_GRADE"" type=""ArrayOfstring_GTEMPINF_IGetEmployeeInfo_GetEmpInfo_LO_GRADE"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_PRJ_DPT"" type=""ArrayOfLO_PRJ_DPT_GTEMPINF_IGetEmployeeInfo_GetEmpInfo_LO_PRJ_DPT"" />
          </xs:sequence>
        </xs:complexType>
      </xs:element>
      <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""TIClientContext"">
        <xs:complexType>
          <xs:attribute name=""TIContextKeyword"" type=""xs:string"" />
          <xs:attribute name=""TIContextValue"" type=""xs:string"" />
        </xs:complexType>
      </xs:element>
    </xs:sequence>
    <xs:attribute default=""1.0"" name=""TIAssemblyVersion"" type=""xs:string"" />
  </xs:complexType>
  <xs:complexType name=""TypeGetEmpInfoResponse"">
    <xs:sequence>
      <xs:element name=""GetEmpInfoOutDocument"">
        <xs:complexType>
          <xs:sequence>
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""CODEMP"" type=""xs:string"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_FNAME"" type=""xs:string"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_LNAME"" type=""xs:string"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_FULLNAME"" type=""xs:string"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_DNI"" type=""xs:string"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_STAT"" type=""xs:string"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_REQ"" type=""xs:decimal"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_HR_CONTRIB_LAST2"" type=""xs:decimal"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_GRADE"" type=""ArrayOfstring_GTEMPINF_IGetEmployeeInfo_GetEmpInfo_LO_GRADE"" />
            <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_PRJ_DPT"" type=""ArrayOfLO_PRJ_DPT_GTEMPINF_IGetEmployeeInfo_GetEmpInfo_LO_PRJ_DPT"" />
          </xs:sequence>
        </xs:complexType>
      </xs:element>
      <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""TIClientContext"">
        <xs:complexType>
          <xs:attribute name=""TIContextKeyword"" type=""xs:string"" />
          <xs:attribute name=""TIContextValue"" type=""xs:string"" />
        </xs:complexType>
      </xs:element>
    </xs:sequence>
    <xs:attribute default=""1.0"" name=""TIAssemblyVersion"" type=""xs:string"" />
  </xs:complexType>
  <xs:complexType name=""ArrayOfstring_GTEMPINF_IGetEmployeeInfo_GetEmpInfo_LO_GRADE"">
    <xs:sequence>
      <xs:element minOccurs=""2"" maxOccurs=""2"" name=""string"" type=""xs:string"" />
    </xs:sequence>
  </xs:complexType>
  <xs:complexType name=""LO_PRJ_DPT"">
    <xs:sequence>
      <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_PRJ_ID"" type=""xs:string"" />
      <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_PRJ_NAME"" type=""xs:string"" />
      <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_DIR_REP"" type=""xs:string"" />
      <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_PRJ_DES"" type=""xs:string"" />
      <xs:element minOccurs=""1"" maxOccurs=""1"" name=""LO_PRJ_VERT"" type=""xs:string"" />
    </xs:sequence>
  </xs:complexType>
  <xs:complexType name=""ArrayOfLO_PRJ_DPT_GTEMPINF_IGetEmployeeInfo_GetEmpInfo_LO_PRJ_DPT"">
    <xs:sequence>
      <xs:element minOccurs=""2"" maxOccurs=""2"" name=""LO_PRJ_DPT"" type=""LO_PRJ_DPT"" />
    </xs:sequence>
  </xs:complexType>
</xs:schema>";
        
        public GTEMPINF() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [2];
                _RootElements[0] = "GTEMPINF__GetEmployeeInfo__GetEmpInfo__Request";
                _RootElements[1] = "GTEMPINF__GetEmployeeInfo__GetEmpInfo__Response";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
        
        [Schema(@"http://microsoft.com/HostApplications/TI/WIP",@"GTEMPINF__GetEmployeeInfo__GetEmpInfo__Request")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"GTEMPINF__GetEmployeeInfo__GetEmpInfo__Request"})]
        public sealed class GTEMPINF__GetEmployeeInfo__GetEmpInfo__Request : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public GTEMPINF__GetEmployeeInfo__GetEmpInfo__Request() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "GTEMPINF__GetEmployeeInfo__GetEmpInfo__Request";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
        
        [Schema(@"http://microsoft.com/HostApplications/TI/WIP",@"GTEMPINF__GetEmployeeInfo__GetEmpInfo__Response")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"GTEMPINF__GetEmployeeInfo__GetEmpInfo__Response"})]
        public sealed class GTEMPINF__GetEmployeeInfo__GetEmpInfo__Response : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public GTEMPINF__GetEmployeeInfo__GetEmpInfo__Response() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "GTEMPINF__GetEmployeeInfo__GetEmpInfo__Response";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
    }
}
