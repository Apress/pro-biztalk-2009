﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.HostIntegration.SNA.Session;

namespace CICSDEMO
{
    public partial class SIDemo : Form
    {
                public static string strTransport = "SNA";
                public static TNDeviceType SDeviceType= TNDeviceType.IBM3278Model2E;
                public static string TN3270Port = "23";
                public static string TN3270Server = "SYS1";
                private System.Drawing.Font m_FixedFont;
                public static SessionDisplay m_Handler = null;
                public static string LUSession = "";
        

        public SIDemo()
        {
            InitializeComponent();   
        }
        public String CurrentScreen()
        {
                if (m_Handler == null)
                    throw new Exception("Not connected");
                String screen = null;
                ScreenData screenData = m_Handler.GetScreenData(1, 1, -1);
                screen = HostStringConverter.ConvertEbcdicToUnicode(screenData.Data);
                return screen;
        }

        private void TraceScreen()
        {
                if (m_Handler == null)
                {
                    ScreenText.ResetText();
                    return;
                }
                string screen = CurrentScreen();
                short rows = m_Handler.Rows;
                short columns = m_Handler.Columns;
                ScreenText.ResetText();
                for (int i = 0; i < rows; i++)
                {
                    ScreenText.Text += (i != 0 ? Environment.NewLine : "") + screen.Substring(columns * i, columns);
                }
                ScreenText.Text += Environment.NewLine + new string('-', (int)columns);
                ScreenText.Refresh();
        }

    private void createSessionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            createSessionToolStripMenuItem.Enabled = false;
            cICSToolStripMenuItem.Enabled = true;
            ispfToolStripMenuItem.Enabled = true;
            disconnectToolStripMenuItem.Enabled = true;

            try
            {
                    m_Handler = new SessionDisplay();

                if (strTransport=="SNA")

                {
                    if (LUSession == "")
                        LUSession = "SYS1LU";
                        m_Handler.Connect("TRANSPORT=SNA;LOGICALUNITNAME=" + LUSession);
                }
                else
                    
                {
                    SessionConnectionDisplay TNDisplay = new SessionConnectionDisplay();
                    TNDisplay.DeviceType = SDeviceType;
                    TNDisplay.Transport = SessionDisplayTransport.TN3270;
                    TNDisplay.TN3270Port = Convert.ToInt32(TN3270Port);
                    TNDisplay.TN3270Server = TN3270Server;
                    m_Handler.Connect(TNDisplay);
                }
                    m_Handler.Connection.HostCodePage = 37;
                    FontFamily fontFamily = new FontFamily("Courier New");
                    m_FixedFont = new Font(fontFamily, 18, FontStyle.Regular, GraphicsUnit.Pixel);
                    ScreenText.Font = m_FixedFont;
                    TraceScreen();
                    m_Handler.WaitForContent("TERM NAME", 20000);
                    TraceScreen();
                    SessionStatusLabel.Text = "Currently in Session";
            }
            catch (Exception ex)
            {
                    MessageBox.Show(ex.Message);
                    createSessionToolStripMenuItem.Enabled = true;
            }    
        }

        private void ClearScreenAndWait()
        {
                m_Handler.SendKey("@C");
                m_Handler.WaitForSession(SessionDisplayWaitType.NotBusy, 20000);
                TraceScreen();
        }
        private void lULUPoolToolStripMenuItem_Click(object sender, EventArgs e)
        {
                SIParameters FormLU = new SIParameters();
                FormLU.Show();
                LULabel.Text = (strTransport == "SNA" ? LUSession + " via SNA" : TN3270Server + ":" + TN3270Port + " via TN3270");
        }
        
        private void SIDemo_Activated(object sender, EventArgs e)
        {
            if (createSessionToolStripMenuItem.Enabled==false)
            LULabel.Text = (strTransport == "SNA" ? LUSession + " via SNA" : TN3270Server + ":" + TN3270Port + " via TN3270");
        }

        private void SIDemo_Load(object sender, EventArgs e)
        {
                disconnectToolStripMenuItem.Enabled = false;
                cICSToolStripMenuItem.Enabled = false;
                ispfToolStripMenuItem.Enabled = false;
        }
        
        private void tN3270ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tN3270ToolStripMenuItem.Checked = true;
            sNAToolStripMenuItem.Checked = false;
            strTransport="TN3270";
            LULabel.Text = (strTransport == "SNA" ? LUSession + " via SNA" : TN3270Server + ":" + TN3270Port + " via TN3270");
        }

        private void disconnectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SessionStatusLabel.Text = "Not Connected";
            ispfToolStripMenuItem.Enabled = false;
            cICSToolStripMenuItem.Enabled = false;
            createSessionToolStripMenuItem.Enabled = true;
            ScreenText.Text = "";
            ScreenText.Refresh();
            disconnectToolStripMenuItem.Enabled = false;
            m_Handler.Disconnect();
            m_Handler = null;
         
         }

      private void getBalanceToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            createSessionToolStripMenuItem.Enabled = false;
            m_Handler.SendKey("CICSDEMO@E");
            TraceScreen();
            m_Handler.WaitForSession(SessionDisplayWaitType.PLUSLU, 5000);
            TraceScreen();
            m_Handler.WaitForContent(@"CICS", 5000);
            TraceScreen();
            //System.Threading.Thread.Sleep(5000);
            try
            {
                ClearScreenAndWait();
                m_Handler.SendKey("WBGB@E");
                TraceScreen();
                m_Handler.WaitForContent("F6=Get Cust", 5000);
                TraceScreen();
                
                GetBalance GBAL = new GetBalance();
                GBAL.ShowDialog();
                m_Handler.CurrentField.Data = GBAL.txtName.Text;
                m_Handler.MoveNextField(new ScreenFieldAttributeData(ScreenFieldAttribute.Normal)).Data = GBAL.txtAccountNumber.Text;
                m_Handler.SendKey("@E");
                
                TraceScreen();
         
                ScreenPartialFieldCollection fields = new ScreenPartialFieldCollection(3);
                fields.Add(new ScreenPartialField("Customer name not found", 21, 2));
                fields.Add(new ScreenPartialField("Name / account could not be found", 21, 2));
                fields.Add(new ScreenPartialField(".", 5, 31));
                int indexOfField = m_Handler.WaitForContent(fields, 5000);
                TraceScreen();
                if (indexOfField == 0)
                    throw new ArgumentException("Customer Name incorrect", GBAL.txtName.Text);
                if (indexOfField == 1)
                    throw new ArgumentException("Account Name incorrect", GBAL.txtAccountNumber.Text);
                string amountString = m_Handler.GetField(5, 20)[2].Data;
                MessageBox.Show("The Account Balance for " + GBAL.txtName.Text+ " is " + amountString.ToString(), "GetBalance CICS Trans.");
                TraceScreen();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void ispfToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cICSToolStripMenuItem.Enabled = false;
            createSessionToolStripMenuItem.Enabled = false;
                       
            m_Handler.SendKey(@"L");
            m_Handler.SendKey(SessionDisplayKeys.Enter);
            TraceScreen();
            m_Handler.WaitForSession(SessionDisplayWaitType.PLUSLU, 2000);
            TraceScreen();
            m_Handler.WaitForContent(@"USER", 2000);

            TraceScreen();

            m_Handler.SendKey("HCAMPOS");
            m_Handler.SendKey(SessionDisplayKeys.Enter);
            TraceScreen();
            m_Handler.WaitForContent("LOGON", 2000);
            TraceScreen();
        }
      
    }
}
