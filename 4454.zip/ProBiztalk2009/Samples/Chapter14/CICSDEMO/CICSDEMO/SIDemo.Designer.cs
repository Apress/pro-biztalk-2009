﻿namespace CICSDEMO
{
    partial class SIDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ScreenText = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.SessionStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.LUNameStrip = new System.Windows.Forms.ToolStripStatusLabel();
            this.LULabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.SessionToolStripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.createSessionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cICSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.getBalanceToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ispfToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disconnectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parametersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lULUPoolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sNAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tN3270ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ScreenText
            // 
            this.ScreenText.BackColor = System.Drawing.Color.Black;
            this.ScreenText.Font = new System.Drawing.Font("Lucida Console", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScreenText.ForeColor = System.Drawing.Color.Green;
            this.ScreenText.Location = new System.Drawing.Point(18, 35);
            this.ScreenText.Multiline = true;
            this.ScreenText.Name = "ScreenText";
            this.ScreenText.Size = new System.Drawing.Size(923, 582);
            this.ScreenText.TabIndex = 2;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SessionStatusLabel,
            this.LUNameStrip,
            this.LULabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 635);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(964, 22);
            this.statusStrip1.TabIndex = 6;
            // 
            // SessionStatusLabel
            // 
            this.SessionStatusLabel.Name = "SessionStatusLabel";
            this.SessionStatusLabel.Size = new System.Drawing.Size(79, 17);
            this.SessionStatusLabel.Text = "Not Connected";
            // 
            // LUNameStrip
            // 
            this.LUNameStrip.Name = "LUNameStrip";
            this.LUNameStrip.Size = new System.Drawing.Size(0, 17);
            // 
            // LULabel
            // 
            this.LULabel.Name = "LULabel";
            this.LULabel.Size = new System.Drawing.Size(0, 17);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SessionToolStripMenu,
            this.parametersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(964, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // SessionToolStripMenu
            // 
            this.SessionToolStripMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createSessionToolStripMenuItem,
            this.cICSToolStripMenuItem,
            this.ispfToolStripMenuItem,
            this.disconnectToolStripMenuItem});
            this.SessionToolStripMenu.Name = "SessionToolStripMenu";
            this.SessionToolStripMenu.Size = new System.Drawing.Size(41, 20);
            this.SessionToolStripMenu.Text = "Main";
            //this.SessionToolStripMenu.Click += new System.EventHandler(this.SessionToolStripMenu_Click);
            // 
            // createSessionToolStripMenuItem
            // 
            this.createSessionToolStripMenuItem.Name = "createSessionToolStripMenuItem";
            this.createSessionToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.createSessionToolStripMenuItem.Text = "Create Session";
            this.createSessionToolStripMenuItem.Click += new System.EventHandler(this.createSessionToolStripMenuItem_Click);
            // 
            // cICSToolStripMenuItem
            // 
            this.cICSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.getBalanceToolStripMenuItem1});
            this.cICSToolStripMenuItem.Name = "cICSToolStripMenuItem";
            this.cICSToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.cICSToolStripMenuItem.Text = "CICS";
            
            // 
            // getBalanceToolStripMenuItem1
            // 
            this.getBalanceToolStripMenuItem1.Name = "getBalanceToolStripMenuItem1";
            this.getBalanceToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.getBalanceToolStripMenuItem1.Text = "GetBalance";
            this.getBalanceToolStripMenuItem1.Click += new System.EventHandler(this.getBalanceToolStripMenuItem1_Click);
            // 
            // ispfToolStripMenuItem
            // 
            this.ispfToolStripMenuItem.Name = "ispfToolStripMenuItem";
            this.ispfToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.ispfToolStripMenuItem.Text = "ISPF";
            this.ispfToolStripMenuItem.Click += new System.EventHandler(this.ispfToolStripMenuItem_Click);
            // 
            // disconnectToolStripMenuItem
            // 
            this.disconnectToolStripMenuItem.Enabled = false;
            this.disconnectToolStripMenuItem.Name = "disconnectToolStripMenuItem";
            this.disconnectToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.disconnectToolStripMenuItem.Text = "Disconnect";
            this.disconnectToolStripMenuItem.Click += new System.EventHandler(this.disconnectToolStripMenuItem_Click);
            // 
            // parametersToolStripMenuItem
            // 
            this.parametersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lULUPoolToolStripMenuItem,
            this.transportToolStripMenuItem});
            this.parametersToolStripMenuItem.Name = "parametersToolStripMenuItem";
            this.parametersToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.parametersToolStripMenuItem.Text = "Parameters";
            // 
            // lULUPoolToolStripMenuItem
            // 
            this.lULUPoolToolStripMenuItem.Name = "lULUPoolToolStripMenuItem";
            this.lULUPoolToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.lULUPoolToolStripMenuItem.Text = "Session Parameters";
            this.lULUPoolToolStripMenuItem.Click += new System.EventHandler(this.lULUPoolToolStripMenuItem_Click);
            // 
            // transportToolStripMenuItem
            // 
            this.transportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sNAToolStripMenuItem,
            this.tN3270ToolStripMenuItem});
            this.transportToolStripMenuItem.Name = "transportToolStripMenuItem";
            this.transportToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.transportToolStripMenuItem.Text = "Transport";
            // 
            // sNAToolStripMenuItem
            // 
            this.sNAToolStripMenuItem.Checked = true;
            this.sNAToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.sNAToolStripMenuItem.Name = "sNAToolStripMenuItem";
            this.sNAToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.sNAToolStripMenuItem.Text = "SNA";
            //this.sNAToolStripMenuItem.Click += new System.EventHandler(this.sNAToolStripMenuItem_Click);
            // 
            // tN3270ToolStripMenuItem
            // 
            this.tN3270ToolStripMenuItem.Name = "tN3270ToolStripMenuItem";
            this.tN3270ToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.tN3270ToolStripMenuItem.Text = "TN3270";
            this.tN3270ToolStripMenuItem.Click += new System.EventHandler(this.tN3270ToolStripMenuItem_Click);
            // 
            // SIDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(964, 657);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.ScreenText);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "SIDemo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Session Integrator Demo";
            this.Load += new System.EventHandler(this.SIDemo_Load);
            this.Activated += new System.EventHandler(this.SIDemo_Activated);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ScreenText;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem SessionToolStripMenu;
        private System.Windows.Forms.ToolStripMenuItem createSessionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cICSToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel SessionStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem parametersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lULUPoolToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tN3270ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sNAToolStripMenuItem;
        
        private System.Windows.Forms.ToolStripStatusLabel LUNameStrip;
        private System.Windows.Forms.ToolStripStatusLabel LULabel;
        private System.Windows.Forms.ToolStripMenuItem disconnectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem getBalanceToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ispfToolStripMenuItem;
    }
}

