﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.HostIntegration.SNA.Session;

namespace CICSDEMO
{
    public partial class SIParameters : Form
    {
        public SIParameters()
        {
            InitializeComponent();
            LUName.Text = SIDemo.LUSession;
        }
        private void cmdSave_Click(object sender, EventArgs e)
        {
            SIDemo.LUSession = LUName.Text;
            SIDemo.TN3270Port = txt3270Port.Text;
            SIDemo.TN3270Server = txt3270Server.Text;
            SIDemo.SDeviceType = (TNDeviceType)Enum.Parse(typeof(TNDeviceType), cboDeviceTypes.SelectedItem.ToString(), true); 
            this.Close();
        }
        private void SIParameters_Load(object sender, EventArgs e)
        {
        foreach(string item in Enum.GetNames(typeof(TNDeviceType)) )
        {
        cboDeviceTypes.DropDownStyle = ComboBoxStyle.DropDownList;
        cboDeviceTypes.Items.Add(item);
        cboDeviceTypes.SelectedItem = "IBM3278Model2E";
        }          
        }

        private void cmdCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
