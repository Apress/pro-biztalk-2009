set-psdebug �strict

[System.Reflection.Assembly]::LoadFrom( "C:\Program Files\Microsoft BizTalk Server 2009\Developer Tools\Microsoft.BizTalk.ExplorerOM.dll" )

[Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer] $BizTalkExpObj = New-Object Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer
	
$BizTalkExpObj.ConnectionString = "SERVER=.;DATABASE=BizTalkMgmtDb;Integrated Security=SSPI"

function DeployApplication
{
	#Set the deployment variables and locations
	$ApplicationName = "BtsAutomatedBuildSample"
	
	$ProjectDirectory = "c:\BtsAutomatedBuildSample"
	
	$BindingFilePath = $ProjectDirectory + "\BtsAutomatedBuildSample.BindingInfo.xml"
	
	$SchemaAssemblyPath = $ProjectDirectory + "\BtsAutomatedBuildSampleSchemas\bin\Debug\BtsAutomatedBuildSampleSchemas.dll"
	$MapAssemblyPath = $ProjectDirectory + "\BtsAutomatedBuildSampleMaps\bin\Debug\BtsAutomatedBuildSampleMaps.dll"
	$PipelineAssemblyPath = $ProjectDirectory + "\BtsAutomatedBuildSamplePipelines\bin\Debug\BtsAutomatedBuildSamplePipelines.dll"
	$PipelineComponentAssemblyPath = $ProjectDirectory + "\BtsAutomatedBuildSamplePipelineComponents\bin\Debug\BtsAutomatedBuildSamplePipelineComponents.dll"
	$OrchestrationAssemblyPath = $ProjectDirectory + "\BtsAutomatedBuildSampleOrchestrations\bin\Debug\BtsAutomatedBuildSampleOrchestrations.dll"

	$BizTalkInstallPath = "c:\Program Files\Microsoft BizTalk Server 2009\Pipeline Components"

	$BizTalkExpObj.Refresh()
	"Refeshing the BizTalk Explorer Object"
	
	#Check to see if the application already exists
	if($BizTalkExpObj.Applications[$ApplicationName].Name -eq $ApplicationName)
	{
		RemoveApplication -BizTalkApplicationName:$ApplicationName
	}
	
	CreateApplication -BizTalkApplicationName:$ApplicationName -BizTalkApplicationDescription:"Sample Build Application"
	
	"Loading Assemblies"
	LoadBizTalkAssembly -assemblyDLL:$SchemaAssemblyPath -BizTalkApplicationName:$ApplicationName
	LoadBizTalkAssembly -assemblyDLL:$MapAssemblyPath -BizTalkApplicationName:$ApplicationName
	LoadBizTalkAssembly -assemblyDLL:$PipelineAssemblyPath -BizTalkApplicationName:$ApplicationName
	LoadBizTalkAssembly -assemblyDLL:$OrchestrationAssemblyPath -BizTalkApplicationName:$ApplicationName
	
	#copy pipeline component
	Copy-Item $PipelineComponentAssemblyPath $BizTalkInstallPath
	
	ImportBindingFile -ApplicationName:$ApplicationName -BindingsFile:$BindingFilePath
	
	ManageApplication -ApplicationName:$ApplicationName -ApplicationOptions:6 -StartApplication:$TRUE 
}


function RemoveApplication
{
	param
	(
		[string] $BizTalkApplicationName
	)

	#Backup the current configuraiton before we remove everything
	ExportApplication -ApplicationName:$BizTalkApplicationName  -ExportPath:"C:\TEMP\"  -PolicyName:$PolicyName -MajorVersion:1 -MinorVersion:0 
	
	"Shutting down any running instances...."
	#Shutdown the application and its send/receive ports
	ManageApplication -ApplicationName:$BizTalkApplicationName  -StartApplication:$FALSE 
	
	"Removing Application...."
	#Remove the application from the administrative database
	RemoveBizTalkApplication -Application:$BizTalkApplicationName
	
	"Commiting Removal Changes......"
	$BizTalkExpObj.SaveChanges()
	$BizTalkExpObj.Refresh()
}


function CreateApplication
{
	param
	(
		[string] $BizTalkApplicationName,
		[string] $BizTalkApplicationDescription
	)
	
	#$BizTalkExpObj.Refresh()
	$Application = $BizTalkExpObj.AddNewApplication();
	
	$Application.Name = $BizTalkApplicationName
	$Application.Description = $BizTalkApplicationDescription
	$BizTalkExpObj.SaveChanges()
}


function CreateHost
{
	param
	(
		[string] $HostName,
		[string] $HostType,
		[string] $NTGroupName,
		[bool]   $Trust
	)
	
	$WMIBizTalkHostSettings = ([WmiClass]�root\MicrosoftBizTalkServer:MSBTS_HostSetting�).PSBase.CreateInstance()
    
            #set the properties for the Managementobject
            $WMIBizTalkHostSettings["Name"] = 'TEST'
            $WMIBizTalkHostSettings["HostType"] = 1 #1 - In process 2-Isolated
            $WMIBizTalkHostSettings["NTGroupName"] = "BizTalk Application Users"
            $WMIBizTalkHostSettings["AuthTrusted"] = -1
            
            #create the Managementobject
            $WMIBizTalkHostSettings.PSBase.Putx(2) #2 = Create Host
}


function LoadBizTalkAssembly
{
	param
	(
		[string] $assemblyDLL,
		[string] $BizTalkApplicationName 
	)
	
	# This is a demonstration of capturing output from a command line application
	$RC = (BTSTask AddResource "/ApplicationName:$BizTalkApplicationName"  "/Type:System.BizTalk:BizTalkAssembly" "/Source:$assemblyDLL"  "/Options:GacOnAdd" "/Overwrite")	
}


function ImportBindingFile
{
	param
	(
		[string] $BindingsFile,
		[string] $ApplicationName
	)

	BTSTask ImportBindings "/ApplicationName:$ApplicationName", "/Source:$BindingsFile"
	
	if($LASTEXITCODE -eq 0)
	{
		"Bindings file succesfully imported"
	}
	else
	{
		"Bindings file FAILED imported"
	}
}


function RemoveBizTalkApplication
{
	param
	(
		[string] $Application
	)
	
	BTSTask RemoveApp "/ApplicationName:$Application"	
}


function ManageApplication
{
	param
	(
		[string] $ApplicationName,
		[bool]   $StartApplication,
		[int]    $ApplicationOptions #6 - Stop All
	)

	$BizTalkExpObj.Refresh()
	[Microsoft.BizTalk.ExplorerOM.Application] $BizTalkApplication = $BizTalkExpObj.Applications[$ApplicationName]	
	
	if($StartApplication -eq $TRUE)
	{		
		foreach($RecPort in $BizTalkApplication.ReceivePorts)
		{
			foreach($RecLoc in $RecPort.ReceiveLocations)
			{
				$RecLoc.Enable = $TRUE
				Write-Output  $RecLoc.PSBase.Name " Starting Receive Location " 
			}
		}
	
		foreach($SendPort in $BizTalkApplication.SendPorts)
		{
			$SendPort.Status =3
			Write-Output  $SendPort.PSBase.Name " Starting Send Port " 
		}
		
		foreach($Orchestration in $BizTalkApplication.Orchestrations)
		{
			$Orchestration.Status = 3
				Write-Output  $Orchestration..PSBase.FullName " Starting Orchestration " 
		}
	}
	else
	{
		foreach($RecPort in $BizTalkApplication.ReceivePorts)
		{
			foreach($RecLoc in $RecPort.ReceiveLocations)
			{
				$RecLoc.Enable = $FALSE
			}
		}
	
		foreach($SendPort in $BizTalkApplication.SendPorts)
		{
			$SendPort.Status =1
		}
		
		foreach($Orchestration in $BizTalkApplication.Orchestrations)
		{
			$Orchestration.Status = 1
		}
	}
	
	Write-Output "Commiting changes...."
	$BizTalkExpObj.SaveChanges()
	Write-Output "Deployment Finished!"
}


function ExportApplication
{
	param
	(
		[string] $ApplicationName,
		[string] $ExportPath,
		[string] $PolicyName,
		[string] $MajorVersion,
		[string] $MinorVersion
	)

	#Export file Names
	$MSIFileName = $ExportPath + $ApplicationName + ".msi"
	$BindingsFileName = $ExportPath + $ApplicationName + "Binding.xml"
	
	#Export the BizTalk Application to an MSI File
	BTSTask ExportApp "/ApplicationName:$ApplicationName" "/Package:$MSIFileName" 	
}

#Call Functions - Script Body

	#Remember that PowerShell runs sequentially and we need to declare the functions before we can call them. 

	DeployApplication

#End of Script