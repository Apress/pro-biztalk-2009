﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsumeAdapterApplication
{
    class Program
    {
        static void Main(string[] args)
        {

            HotelServiceClient client = new HotelServiceClient();
            client.ClientCredentials.UserName.UserName = "username";
            string response = client.GetRooms("Indigo hotel");
            Console.WriteLine(response);
            Console.Read();
            //EchoServiceClient client = new EchoServiceClient();
            //client.ClientCredentials.UserName.UserName = "a";
            //string response = client.EchoString("Indigo hotel");
            //Console.WriteLine(response);
            //Console.Read();

        }
    }
}
