﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsumeAdapterApplicationInbound
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //uncomment the line below to attach a debugger
                //Console.ReadLine();
                System.ServiceModel.ServiceHost host = new System.ServiceModel.ServiceHost(typeof(HotelAdapterBindingNamespace.HotelAdapterBindingService));

                // Open the ServiceHost to start listening for messages
                host.Open();

                Console.WriteLine("The service is ready.");
                Console.WriteLine("Press <ENTER> to terminate service.");
                Console.ReadLine();

                // Close the ServiceHost
                host.Close();
            }
            catch (TimeoutException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine();
                Console.Read();
            }
            catch (System.ServiceModel.CommunicationException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine();
                Console.Read();
            }
        }
    }
}
