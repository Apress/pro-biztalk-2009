/// -----------------------------------------------------------------------------------------------------------
/// Module      :  HotelAdapterInboundHandler.cs
/// Description :  This class implements an interface for listening or polling for data.
/// -----------------------------------------------------------------------------------------------------------
/// 
#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;
using System.ServiceModel.Channels;
using System.Timers;
using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace HotelApp.HotelAdapter
{
    public class HotelAdapterInboundHandler : 
        HotelAdapterHandlerBase, IInboundHandler
    {

        private Queue<Message> inboundMessages;
        private Timer pollingTimer;
        private Object syncLock;
        private int pollingPeriod;
        
        /// <summary>
        /// Initializes a new instance of 
        /// the HotelAdapterInboundHandler class
        /// </summary>
        public HotelAdapterInboundHandler(HotelAdapterConnection connection
            , MetadataLookup metadataLookup)
            : base(connection, metadataLookup)
        {
            pollingPeriod = 
                connection.ConnectionFactory.Adapter.PollingPeriod;
            syncLock = new Object();
        }
        #region IInboundHandler Members

        /// <summary>
        /// Start the listener
        /// </summary>
        public void StartListener(string[] actions, TimeSpan timeout)
        {
            //listen for all actions
            //create a Queue to hold inbound messages;
            inboundMessages = new Queue<Message>();
            //set up a timer to pool for guest arrivals

            pollingTimer = new System.Timers.Timer(pollingPeriod * 1000);
            pollingTimer.Elapsed += 
                new System.Timers.ElapsedEventHandler(CheckArrivals);
            pollingTimer.Enabled = true;
        }

        /// <summary>
        /// Stop the listener
        /// </summary>
        public void StopListener(TimeSpan timeout)
        {
            if (pollingTimer != null)
            {
                pollingTimer.Stop();
                pollingTimer = null;
            }
            lock (syncLock)
            {
                inboundMessages.Clear();
                inboundMessages = null;
            }
        }

        /// <summary>
        /// Tries to receive a message within a specified interval of time. 
        /// </summary>
        public bool TryReceive(TimeSpan timeout, 
                           out System.ServiceModel.Channels.Message message,
                           out IInboundReply reply)
        {
            reply = new HotelAdapterInboundReply();
            message = null;

            //assume timeout is infinite
            while (true)
            {
                lock (syncLock)
                {
                    if (inboundMessages == null)
                    {
                        //listener has been closed
                        return false;
                    }
                    if (inboundMessages.Count != 0)
                    {
                        message = inboundMessages.Dequeue();
                        if (message != null)
                        {
                            return true;
                        }
                    }
                }
                System.Threading.Thread.Sleep(500);
            }
        }

        /// <summary>
        /// Returns a value that indicates whether a message
        /// has arrived within a specified interval of time.
        /// </summary>
        public bool WaitForMessage(TimeSpan timeout)
        {
            //wait for message to appear in the queue
            while (inboundMessages.Count == 0) { };
            //check if message is there but don't remove it
            Message msg = inboundMessages.Peek();
            if (msg != null)
            {
                return true;
            }
            return false;
        }
        #endregion IInboundHandler Members
        private void CheckArrivals(object sender, ElapsedEventArgs args)
        {
            //poll for example a database
            //if new guest found create inbound message
            HotelAdapter adapter = this.Connection.ConnectionFactory.Adapter;
            String xmlData = String.Format(@"<OnGuestArrived xmlns=""{0}"">
                                 <FirstName>{1}</FirstName>
                                 <LastName>{2}</LastName></OnGuestArrived>",
                                 adapter.ServiceNamespace,
                                 "John",
                                 "Smith");
            XmlReader reader = XmlReader.Create(new StringReader(xmlData));
            // create WCF message
            Message requestMessage = 
                Message.CreateMessage(MessageVersion.Default
                        , "Hotel/OnGuestArrived"
                        , reader);
            // add it to inbound queue
            inboundMessages.Enqueue(requestMessage);
        }
    }
    internal class HotelAdapterInboundReply : InboundReply
    {
        #region InboundReply Members

        /// <summary>
        /// Abort the inbound reply call
        /// </summary>
        public override void Abort()
        {
            //
            //TODO: Implement abort logic.
            //

        }

        /// <summary>
        /// Reply message implemented
        /// </summary>
        public override void Reply(System.ServiceModel.Channels.Message message
            , TimeSpan timeout)
        {
            //
            //TODO: Implement reply logic.
            //


        }


        #endregion InboundReply Members
    }


}
