/// -----------------------------------------------------------------------------------------------------------
/// Module      :  HotelAdapterBindingElementExtensionElement.cs
/// Description :  This class is provided to surface Adapter as a binding element, so that it 
///                can be used within a user-defined WCF "Custom Binding".
///                In configuration file, it is defined under
///                <system.serviceModel>
///                  <extensions>
///                     <bindingElementExtensions>
///                         <add name="{name}" type="{this}, {assembly}"/>
///                     </bindingElementExtensions>
///                  </extensions>
///                </system.serviceModel>
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Configuration;
using System.ServiceModel.Channels;
using System.Configuration;
using System.Globalization;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace HotelApp.HotelAdapter
{
    using System;
    using System.Configuration;
    using System.ServiceModel;
    using System.ServiceModel.Channels;
    using System.ServiceModel.Configuration;

    public class HotelAdapterBindingElementExtensionElement : BindingElementExtensionElement
    {

        #region  Constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        public HotelAdapterBindingElementExtensionElement()
        {
        }

        #endregion Constructor

        #region Custom Generated Properties

        [System.Configuration.ConfigurationProperty("connectionPooling", DefaultValue = true)]
        public bool ConnectionPooling
        {
            get
            {
                return ((bool)(base["ConnectionPooling"]));
            }
            set
            {
                base["ConnectionPooling"] = value;
            }
        }



        [System.Configuration.ConfigurationProperty("pollingPeriod", DefaultValue = 10)]
        public int PollingPeriod
        {
            get
            {
                return ((int)(base["PollingPeriod"]));
            }
            set
            {
                base["PollingPeriod"] = value;
            }
        }

        #endregion Custom Generated Properties

        #region BindingElementExtensionElement Methods
        /// <summary>
        /// Return the type of the adapter (binding element)
        /// </summary>
        public override Type BindingElementType
        {
            get
            {
                return typeof(HotelAdapter);
            }
        }
        /// <summary>
        /// Returns a collection of the configuration properties
        /// </summary>
        protected override ConfigurationPropertyCollection Properties
        {
            get
            {
                ConfigurationPropertyCollection configProperties = base.Properties;
                configProperties.Add(new ConfigurationProperty("ConnectionPooling", typeof(System.Boolean), true, null, null, ConfigurationPropertyOptions.None));
                configProperties.Add(new ConfigurationProperty("PollingPeriod", typeof(System.Int32), (System.Int32)10, null, null, ConfigurationPropertyOptions.None));
                return configProperties;
            }
        }

        /// <summary>
        /// Instantiate the adapter.
        /// </summary>
        /// <returns></returns>
        protected override BindingElement CreateBindingElement()
        {
            HotelAdapter adapter = new HotelAdapter();
            this.ApplyConfiguration(adapter);
            return adapter;
        }

        /// <summary>
        /// Apply the configuration properties to the adapter.
        /// </summary>
        /// <param name="bindingElement"></param>
        public override void ApplyConfiguration(BindingElement bindingElement)
        {
            base.ApplyConfiguration(bindingElement);
            HotelAdapter adapterBinding = ((HotelAdapter)(bindingElement));
            adapterBinding.ConnectionPooling = (System.Boolean)this["ConnectionPooling"];
            adapterBinding.PollingPeriod = (System.Int32)this["PollingPeriod"];
        }

        /// <summary>
        /// Initialize the binding properties from the adapter.
        /// </summary>
        /// <param name="bindingElement"></param>
        protected override void InitializeFrom(BindingElement bindingElement)
        {
            base.InitializeFrom(bindingElement);
            HotelAdapter adapterBinding = ((HotelAdapter)(bindingElement));
            this["ConnectionPooling"] = adapterBinding.ConnectionPooling;
            this["PollingPeriod"] = adapterBinding.PollingPeriod;
        }

        /// <summary>
        /// Copy the properties to the custom binding
        /// </summary>
        /// <param name="from"></param>
        public override void CopyFrom(ServiceModelExtensionElement from)
        {
            base.CopyFrom(from);
            HotelAdapterBindingElementExtensionElement adapterBinding = ((HotelAdapterBindingElementExtensionElement)(from));
            this["ConnectionPooling"] = adapterBinding.ConnectionPooling;
            this["PollingPeriod"] = adapterBinding.PollingPeriod;
        }

        #endregion BindingElementExtensionElement Methods
    }
}

