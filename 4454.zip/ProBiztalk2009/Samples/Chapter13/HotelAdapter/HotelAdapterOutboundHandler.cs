/// -----------------------------------------------------------------------------------------------------------
/// Module      :  HotelAdapterOutboundHandler.cs
/// Description :  This class is used for sending data to the target system
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel.Channels;
using System.Xml;
using System.IO;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace HotelApp.HotelAdapter
{
    public class HotelAdapterOutboundHandler : HotelAdapterHandlerBase, 
                                               IOutboundHandler
    {
        /// <summary>
        /// Initializes a new instance of the HotelAdapterOutboundHandler class
        /// </summary>
        public HotelAdapterOutboundHandler(HotelAdapterConnection connection
            , MetadataLookup metadataLookup)
            : base(connection, metadataLookup)
        {
        }

        #region IOutboundHandler Members

        /// <summary>
        /// Executes the request message on the target system 
        /// and returns a response message.
        /// If there isn�t a response, this method should return null
        /// </summary>
        public Message Execute(Message message, TimeSpan timeout)
        {
            OperationMetadata om = this.MetadataLookup.
                                 GetOperationDefinitionFromInputMessageAction(
                                               message.Headers.Action, timeout);
            if (om == null)
            {
                throw new AdapterException("Invalid action " + 
                                                message.Headers.Action);
            }
            //actions are specified in the proxy files 
            //or can be configured in WCF-custom adapter
            switch (message.Headers.Action)
            {
                case "Hotel/GetRooms":
                    XmlDictionaryReader inputReader = 
                        message.GetReaderAtBodyContents();
                    // move to the content
                    while (inputReader.Read())
                    {
                        if ((String.IsNullOrEmpty(inputReader.Prefix) && 
                                       inputReader.Name.Equals("hotelName"))
                            || inputReader.Name.Equals(
                                    inputReader.Prefix + ":" + "hotelName")) 
                            break;
                    }
                    inputReader.Read();
                    //assume there are 10 rooms available.
                    string responseValue = inputReader.Value + ":10 rooms";
                    StringBuilder outputString = new StringBuilder();
                    XmlWriterSettings settings = new XmlWriterSettings();
                    settings.OmitXmlDeclaration = true;
                    // Create response message
                    XmlWriter replywriter = XmlWriter.Create(outputString, settings);
                    replywriter.WriteStartElement("GetRoomsResponse", 
                        HotelAdapter.SERVICENAMESPACE);
                    replywriter.WriteElementString("GetRoomsResult", 
                        responseValue);
                    replywriter.WriteEndElement();
                    replywriter.Close();

                    XmlReader replyReader = 
                        XmlReader.Create(
                                new StringReader(outputString.ToString()));
                    // Output Message Format
                    // <GetRoomsResponse><GetRoomsResult>{rooms}
                    //</GetRoomsResult></GetRoomsResponse>
                    // create output message
                    return Message.CreateMessage(
                            MessageVersion.Default,
                            "Hotel/GetRooms/response",
                            replyReader);
                default: throw new AdapterException("Invalid action " + 
                    message.Headers.Action);
            }
        }
        #endregion IOutboundHandler Members
    }
}
