/// -----------------------------------------------------------------------------------------------------------
/// Module      :  HotelAdapterMetadataSearchHandler.cs
/// Description :  This class is used for performing a connection-based search for metadata from the target system
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.ServiceModel.Channels;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace HotelApp.HotelAdapter
{
    public class HotelAdapterMetadataSearchHandler : HotelAdapterHandlerBase, IMetadataSearchHandler
    {
        /// <summary>
        /// Initializes a new instance of the HotelAdapterMetadataSearchHandler class
        /// </summary>
        public HotelAdapterMetadataSearchHandler(HotelAdapterConnection connection
            , MetadataLookup metadataLookup)
            : base(connection, metadataLookup)
        {
        }

        #region IMetadataSearchHandler Members
        /// <summary>
        /// Retrieves an array of MetadataRetrievalNodes
        /// (see Microsoft.ServiceModel.Channels) from the target system.
        /// The search will begin at the path provided in absoluteName,
        /// which points to a location in the tree of metadata nodes.
        /// The contents of the array are filtered by SearchCriteria and the
        /// number of nodes returned is limited by maxChildNodes.
        /// The method should complete within the specified timespan or 
        /// throw a timeout exception.  If absoluteName is null or an 
        /// empty string, return nodes starting from the root.
        /// If SearchCriteria is null or an empty string, return all nodes.
        /// </summary>
        public MetadataRetrievalNode[] Search(string nodeId
            , string searchCriteria
            , int maxChildNodes, TimeSpan timeout)
        {
            List<MetadataRetrievalNode> searchResult = 
                            new List<MetadataRetrievalNode>();

            searchCriteria = searchCriteria.ToLower();
            //we have only two operations
            // check them one by one
            if ("OnClientArrived".ToLower().Contains(searchCriteria))
            {
                MetadataRetrievalNode nodeInbound = 
                    new MetadataRetrievalNode("Hotel/OnClientArrived");
                nodeInbound.DisplayName = "OnClientArrived";
                nodeInbound.Description = @"This operation notifies
                                    external clients of client arrival.";
                nodeInbound.Direction = 
                    MetadataRetrievalNodeDirections.Inbound;
                nodeInbound.IsOperation = true;
                searchResult.Add(nodeInbound);
            }
            if ("GetRooms".ToLower().Contains(searchCriteria))
            {
                MetadataRetrievalNode nodeOutbound = 
                    new MetadataRetrievalNode("Hotel/GetRooms");
                nodeOutbound.DisplayName = "GetRooms";
                nodeOutbound.Description = @"This operation returns the 
                                             number of available rooms.";
                nodeOutbound.Direction = 
                    MetadataRetrievalNodeDirections.Outbound;
                nodeOutbound.IsOperation = true;
                searchResult.Add(nodeOutbound);
            }
            return searchResult.ToArray();
        }
        #endregion IMetadataSearchHandler Members
    }
}
