/// -----------------------------------------------------------------------------------------------------------
/// Module      :  HotelAdapterConnectionUri.cs
/// Description :  This is the class for representing an adapter connection uri
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace HotelApp.HotelAdapter
{
    /// <summary>
    /// This is the class for building the HotelAdapterConnectionUri
    /// </summary>
    public class HotelAdapterConnectionUri : ConnectionUri
    {
        private UriBuilder uriBuilder;

        #region Custom Generated Fields

        private string application = "HotelApp";


        private bool enableAuthentication = false;


        private string host = "HotelAppHost";

        #endregion Custom Generated Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the ConnectionUri class
        /// </summary>
        public HotelAdapterConnectionUri() 
        {
            uriBuilder =
            new UriBuilder(@"hotel://ProBiztalk/
                HotelApp?enableAuthentication=false");
        }

        /// <summary>
        /// Initializes a new instance of the ConnectionUri 
        /// class with a Uri object
        /// </summary>
        public HotelAdapterConnectionUri(Uri uri)
            : base()
        {
            uriBuilder = new UriBuilder(uri);
        }

        #endregion Constructors

        #region Custom Generated Properties

        [System.ComponentModel.Category("Connection")]
        public string Application
        {
            get
            {
                return this.application;
            }
            set
            {
                this.application = value;
            }
        }
        
        [System.ComponentModel.Category("Connection")]
        public bool EnableAuthentication
        {
            get
            {
                return this.enableAuthentication;
            }
            set
            {
                this.enableAuthentication = value;
            }
        }

        [System.ComponentModel.Category("Connection")]
        public string Host
        {
            get
            {
                return this.host;
            }
            set
            {
                this.host = value;
            }
        }

        #endregion Custom Generated Properties

        #region ConnectionUri Members

        /// <summary>
        /// Getter and Setter for the Uri
        /// </summary>
        public override Uri Uri
        {
            get
            {
                //check if connection string elements are specified 
                if (String.IsNullOrEmpty(this.host))
                {
                    throw new InvalidUriException("Host name must be specified.");
                }
                if (String.IsNullOrEmpty(this.application))
                {
                    throw new InvalidUriException(
                        "Application name must be specified.");
                }
                // the connection uri object
                this.uriBuilder.Scheme = HotelAdapter.SCHEME;
                this.uriBuilder.Host = host;
                this.uriBuilder.Path = application;
                this.uriBuilder.Query = "enableAuthentication=" 
                    + enableAuthentication.ToString();
                return uriBuilder.Uri;
                
            }
            set
            {
                this.host = value.Host;
                //walk through connection string segments and get app name
                //it is in the last segment
                if (value.Segments != null && value.Segments.Length > 1)
                {
                    foreach (string segment in value.Segments)
                    {
                        application = segment;
                    }
                }
                this.enableAuthentication = false;
                string[] enableAuthenticationValue = 
                    GetQueryStringValue(value, "enableAuthentication");
                if (enableAuthenticationValue.Length == 1)
                {
                    this.enableAuthentication = 
                        Boolean.Parse(enableAuthenticationValue[0]);
                }
            }
        }

        /// <summary>
        /// Returns the sample connection string 
        /// to be presented in UI design-time tools
        /// </summary>
        public override string SampleUriString
        {
            get
            {
                return HotelAdapter.SCHEME + 
                    "://{host}/{application}?enableAuthentication={true,false}";
            }
        }


        #endregion ConnectionUri Members


    }
}