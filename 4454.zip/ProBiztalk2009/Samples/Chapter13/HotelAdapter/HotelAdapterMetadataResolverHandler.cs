/// -----------------------------------------------------------------------------------------------------------
/// Module      :  HotelAdapterMetadataResolverHandler.cs
/// Description :  This class is used for performing a connection-based retrieval of metadata from the target system.
/// ----------------------------------------------------------------------------------------------------------- 

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Schema;
using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace HotelApp.HotelAdapter
{
    public class HotelAdapterMetadataResolverHandler : HotelAdapterHandlerBase, IMetadataResolverHandler
    {
        /// <summary>
        /// Initializes a new instance of the HotelAdapterMetadataResolverHandler class
        /// </summary>
        public HotelAdapterMetadataResolverHandler(HotelAdapterConnection connection
            , MetadataLookup metadataLookup)
            : base(connection, metadataLookup)
        {
        }

        #region IMetadataResolver Members

        /// <summary>
        /// Returns a value indicating whether the specified operation metadata is valid
        /// The DateTime field is provided to indicate when this specific operation metadata was last retrieved from the source system.
        /// The method should complete within the specified timespan or throw a timeout exception.
        /// </summary>
        public bool IsOperationMetadataValid(string operationId, DateTime lastUpdatedTimestamp, TimeSpan timeout)
        {
            //
            //TODO: Check the validity of the operation metadata on the target system.
            //      Examples include identifying any relevant changes in the target system, expiration of validity time interval etc.
            //
            switch (operationId)
            {
                case "Hotel/RegisterClient":
                case "Hotel/OnGuestArrived":
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Returns a value indicating whether the specified type metadata is valid.
        /// The DateTime field is provided to indicate when this specific type metadata was last retrieved from the source system.
        /// The method should complete within the specified timespan or throw a timeout exception.
        /// </summary>
        public bool IsTypeMetadataValid(string typeId, DateTime lastUpdatedTimestamp, TimeSpan timeout)
        {
            //
            //TODO: Check the validity of the type metadata on the target system.
            //      Metadata validity might constitute things like changes, expiry and etc.

            //throw new NotImplementedException("The method or operation is not implemented.");
            return true;
        }

        /// <summary>
        /// Returns an OperationMetadata object resolved from absolute 
        /// name of the operation metadata object.
        /// The method should complete within the specified time 
        /// span or throw a timeout exception.
        /// </summary>
        public OperationMetadata ResolveOperationMetadata(string operationId,
                        TimeSpan timeout, 
                        out TypeMetadataCollection extraTypeMetadataResolved)
        {
            extraTypeMetadataResolved = null;
            ParameterizedOperationMetadata om = 
                new ParameterizedOperationMetadata(operationId, operationId);
            // set this if you want this operation to belong 
            // to this interface name
            // in the generated proxy, the interface name 
            // will be HotelService and the client implementation name 
            // will be HotelServiceClient.
            om.OperationGroup = "HotelService";
            // set the operation namespace to be same as service namespace
            om.OperationNamespace = HotelAdapter.SERVICENAMESPACE;
            switch (operationId)
            {
                case "Hotel/GetRooms":
                    om.DisplayName = "GetRooms";
                    om.OriginalName = "originalGetRooms";
                    // syntax: String SayHelloWorld( String aName );
                    OperationParameter parm1 = 
                        new OperationParameter("hotelName", 
                            OperationParameterDirection.In, 
                            QualifiedType.StringType, false);
                    parm1.Description = @"This string will 
                        contain hotel name for which 
                        number of rooms is being requested";
                    OperationResult result = 
                        new OperationResult(new 
                            SimpleQualifiedType(XmlTypeCode.String), false);
                    om.Parameters.Add(parm1);
                    om.OperationResult = result;
                    return om;
                case "Hotel/OnGuestArrived":
                    om.DisplayName = "OnGuestArrived";
                    om.OriginalName = "originalOnGuestArrived";
                    // syntax: void ShowAlert( string name, string data );
                    OperationParameter pName = 
                        new OperationParameter("FirstName", 
                            OperationParameterDirection.In, 
                            QualifiedType.StringType, false);
                    pName.Description = "Guest's first name.";
                    OperationParameter pLastName = 
                        new OperationParameter("LastName", 
                            OperationParameterDirection.In, 
                            QualifiedType.StringType, false);
                    pLastName.Description = "Guest's last name.";
                    om.Parameters.Add(pName);
                    om.Parameters.Add(pLastName);
                    om.OperationResult = null;
                    return om;
            }
            return null;
        }

        /// <summary>
        /// Returns a TypeMetadata object resolved from the absolute name of the type metadata object.
        /// The method should complete within the specified time span or throw a timeout exception.
        /// </summary>
        public TypeMetadata ResolveTypeMetadata(string typeId, TimeSpan timeout, out TypeMetadataCollection extraTypeMetadataResolved)
        {
            extraTypeMetadataResolved = null;

            //
            //TODO: Retrieve type metadata from the target system and present it 
            //      as an implementation of the OperationMetadata base class.
            //      Type metadata represents target system supported types 
            //      as passed and returned through operation parameters.
            //
            throw new NotImplementedException("The method or operation is not implemented.");
        }

        #endregion IMetadataResolver Members
    }


}
