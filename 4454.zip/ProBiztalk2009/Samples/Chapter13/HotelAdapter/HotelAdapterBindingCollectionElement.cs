/// -----------------------------------------------------------------------------------------------------------
/// Module      :  HotelAdapterBindingCollectionElement.cs
/// Description :  Binding Collection Element class which implements the StandardBindingCollectionElement
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Configuration;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace HotelApp.HotelAdapter
{
    /// <summary>
    /// Initializes a new instance of the HotelAdapterBindingCollectionElement class
    /// </summary>
    public class HotelAdapterBindingCollectionElement : StandardBindingCollectionElement<HotelAdapterBinding,
        HotelAdapterBindingElement>
    {
    }
}

