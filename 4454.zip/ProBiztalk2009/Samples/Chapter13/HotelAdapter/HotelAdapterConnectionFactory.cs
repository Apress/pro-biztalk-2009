/// -----------------------------------------------------------------------------------------------------------
/// Module      :  HotelAdapterConnectionFactory.cs
/// Description :  Defines the connection factory for the target system.
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.IdentityModel.Selectors;
using System.ServiceModel.Description;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace HotelApp.HotelAdapter
{
    public class HotelAdapterConnectionFactory : IConnectionFactory
    {
        #region Private Fields

        // Stores the client credentials
        private ClientCredentials clientCredentials;
        // Stores the adapter class
        private HotelAdapter adapter;
        private HotelAdapterConnectionUri uri;

        #endregion Private Fields

        /// <summary>
        /// Initializes a new instance of the HotelAdapterConnectionFactory class
        /// </summary>
        public HotelAdapterConnectionFactory(ConnectionUri connectionUri
            , ClientCredentials clientCredentials
            , HotelAdapter adapter)
        {
            this.uri = (HotelAdapterConnectionUri)connectionUri;
            this.clientCredentials = clientCredentials;
            this.adapter = adapter;
        }

        #region Public Properties

        /// <summary>
        /// Gets the adapter
        /// </summary>
        public HotelAdapter Adapter
        {
            get
            {
                return this.adapter;
            }
        }

        /// <summary>
        /// Returns the client credentials
        /// </summary>
        public ClientCredentials ClientCredentials
        {
            get
            {
                return this.clientCredentials;
            }
        }
        /// <summary>
        /// Returns the connectionuri
        /// </summary>
        public HotelAdapterConnectionUri Uri
        {
            get
            {
                return this.uri;
            }
        }

        #endregion Public Properties

        #region Public Methods

        /// <summary>
        /// Creates the connection to the target system
        /// </summary>
        public IConnection CreateConnection()
        {
            return new HotelAdapterConnection(this);
        }

        #endregion Public Methods
    }
}
