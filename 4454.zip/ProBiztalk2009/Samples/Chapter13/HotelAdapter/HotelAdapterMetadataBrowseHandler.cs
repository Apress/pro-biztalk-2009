/// -----------------------------------------------------------------------------------------------------------
/// Module      :  HotelAdapterMetadataBrowseHandler.cs
/// Description :  This class is used while performing a connection-based browse for metadata from the target system.
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.ServiceModel.Channels;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace HotelApp.HotelAdapter
{
    public class HotelAdapterMetadataBrowseHandler : HotelAdapterHandlerBase, IMetadataBrowseHandler
    {
        /// <summary>
        /// Initializes a new instance of the HotelAdapterMetadataBrowseHandler class
        /// </summary>
        public HotelAdapterMetadataBrowseHandler(HotelAdapterConnection connection
            , MetadataLookup metadataLookup)
            : base(connection, metadataLookup)
        {
        }

        #region IMetadataBrowseHandler Members
        /// <summary>
        /// Retrieves an array of MetadataRetrievalNodes from the target 
        /// system. The browse will return nodes starting from the 
        /// childStartIndex in the path provided in absoluteName, and 
        /// the number of nodes returned is limited by maxChildNodes.
        /// The method should complete within the specified timespan or
        /// throw a timeout exception.
        /// If absoluteName is null or an empty string, return nodes starting 
        /// from the root + childStartIndex.
        /// If childStartIndex is zero, then return starting at the node 
        /// indicated by absoluteName (or the root node if 
        /// absoluteName is null or empty).
        /// </summary>
        public MetadataRetrievalNode[] Browse(string nodeId
            , int childStartIndex
            , int maxChildNodes, TimeSpan timeout)
        {
            //WCF LOB SDK UI tools by deafult start with the root "\" node.
            //for the root node there is only one category "Hotel Operations"
            if (MetadataRetrievalNode.Root.NodeId.CompareTo(nodeId) == 0)
            {
                // Create an inbound and outbound category 
                //under the root node
                MetadataRetrievalNode node = new 
                    MetadataRetrievalNode("HotelOperations");
                node.NodeId = "HotelOperations";
                node.DisplayName = "Hotel Operations";
                node.Description = @"This category contains inbound and 
                        outbound operations supported by the HotelAdapter.";
                node.Direction = MetadataRetrievalNodeDirections.Inbound | 
                                   MetadataRetrievalNodeDirections.Outbound;
                node.IsOperation = false;
                return new MetadataRetrievalNode[] { node };
            }
                // if user selected "HotelOperations" in 
                //the "Select Category" control populated 
                //return two operations
                //OnGuestArrived in Inbound scenario
                //GetRooms in outbound
             else if ("HotelOperations".CompareTo(nodeId) == 0)
            {
                // Create outbound operation
                MetadataRetrievalNode nodeOutbound = 
                           new MetadataRetrievalNode("Hotel/GetRooms");
                nodeOutbound.NodeId = "Hotel/GetRooms";
                nodeOutbound.DisplayName = "GetRooms";
                nodeOutbound.Description = 
                     "This operation returns the number of available rooms.";
                nodeOutbound.Direction = 
                    MetadataRetrievalNodeDirections.Outbound;
                nodeOutbound.IsOperation = true;
                // Create inbound operation
                MetadataRetrievalNode nodeInbound = 
                    new MetadataRetrievalNode("Hotel/OnGuestArrived");
                nodeInbound.NodeId = "Hotel/OnGuestArrived";
                nodeInbound.DisplayName = "OnGuestArrived";
                nodeInbound.Description = 
                         "This operation notifies of client arrival.";
                nodeInbound.Direction = 
                    MetadataRetrievalNodeDirections.Inbound;
                nodeInbound.IsOperation = true;
                return new MetadataRetrievalNode[] 
                             { nodeOutbound, nodeInbound };
            }
            return null;
        }
        #endregion IMetadataBrowseHandler Members
    }
    public interface IMetadataSearchHandler : IConnectionHandler, IDisposable
    {
        MetadataRetrievalNode[] Search(string nodeId, string searchCriteria,
                                            int maxChildNodes, TimeSpan timeout);
    }

}
