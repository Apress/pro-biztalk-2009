/// -----------------------------------------------------------------------------------------------------------
/// Module      :  HotelAdapterBindingElement.cs
/// Description :  Provides a base class for the configuration elements.
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Configuration;
using System.ServiceModel.Channels;
using System.Configuration;
using System.Globalization;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace HotelApp.HotelAdapter
{
    public class HotelAdapterBindingElement : StandardBindingElement
    {
        private ConfigurationPropertyCollection properties;

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the HotelAdapterBindingElement class
        /// </summary>
        public HotelAdapterBindingElement()
            : base(null)
        {
        }


        /// <summary>
        /// Initializes a new instance of the HotelAdapterBindingElement class with a configuration name
        /// </summary>
        public HotelAdapterBindingElement(string configurationName)
            : base(configurationName)
        {
        }

        #endregion Constructors

        #region Custom Generated Properties

        [System.ComponentModel.Category("")]
        [System.Configuration.ConfigurationProperty("connectionPooling", 
                                                  DefaultValue = true)]
        public bool ConnectionPooling
        {
            get
            {
                return ((bool)(base["ConnectionPooling"]));
            }
            set
            {
                base["ConnectionPooling"] = value;
            }
        }


        [System.ComponentModel.Category("Inbound")]
        [System.Configuration.ConfigurationProperty("pollingPeriod", 
            DefaultValue = 10)]
        public int PollingPeriod
        {
            get
            {
                return ((int)(base["PollingPeriod"]));
            }
            set
            {
                base["PollingPeriod"] = value;
            }
        }

        #endregion Custom Generated Properties

        #region Protected Properties

        /// <summary>
        /// Gets the type of the BindingElement
        /// </summary>
        protected override Type BindingElementType
        {
            get
            {
                return typeof(HotelAdapterBinding);
            }
        }

        #endregion Protected Properties

        #region StandardBindingElement Members

        /// <summary>
        /// Initializes the binding with the configuration properties
        /// </summary>
        protected override void InitializeFrom(Binding binding)
        {
            base.InitializeFrom(binding);
            HotelAdapterBinding adapterBinding = (HotelAdapterBinding)binding;
            this["ConnectionPooling"] = adapterBinding.ConnectionPooling;
            this["PollingPeriod"] = adapterBinding.PollingPeriod;
        }

        /// <summary>
        /// Applies the configuration
        /// </summary>
        protected override void OnApplyConfiguration(Binding binding)
        {
            if (binding == null)
                throw new ArgumentNullException("binding");

            HotelAdapterBinding adapterBinding = (HotelAdapterBinding)binding;
            adapterBinding.ConnectionPooling = (System.Boolean)this["ConnectionPooling"];
            adapterBinding.PollingPeriod = (System.Int32)this["PollingPeriod"];
        }

        /// <summary>
        /// Returns a collection of the configuration properties
        /// </summary>
        protected override ConfigurationPropertyCollection Properties
        {
            get
            {
                if (this.properties == null)
                {
                    ConfigurationPropertyCollection configProperties = base.Properties;
                    configProperties.Add(new ConfigurationProperty("ConnectionPooling", typeof(System.Boolean), true, null, null, ConfigurationPropertyOptions.None));
                    configProperties.Add(new ConfigurationProperty("PollingPeriod", typeof(System.Int32), (System.Int32)10, null, null, ConfigurationPropertyOptions.None));
                    this.properties = configProperties;
                }
                return this.properties;
            }
        }


        #endregion StandardBindingElement Members
    }
}
