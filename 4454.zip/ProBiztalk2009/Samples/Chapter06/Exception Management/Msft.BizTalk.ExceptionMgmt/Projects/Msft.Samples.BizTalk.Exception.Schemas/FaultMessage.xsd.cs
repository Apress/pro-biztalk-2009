namespace Msft.Samples.BizTalk.Exception.Schemas {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://schemas.msft.samples.biztalk.com/exceptionmanagement",@"FaultEnvelope")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "Application", XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='Application' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "FailureCategory", XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FailureCategory' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "FaultCode", XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FaultCode' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "FaultDescription", XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FaultDescription' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.Int32), "FaultSeverity", XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FaultSeverity' and namespace-uri()='']", XsdType = @"int")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "Scope", XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='Scope' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Msft.Samples.BizTalk.Exception.Schemas.Application), XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='Application' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Msft.Samples.BizTalk.Exception.Schemas.FailureCategory), XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FailureCategory' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Msft.Samples.BizTalk.Exception.Schemas.FaultCode), XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FaultCode' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Msft.Samples.BizTalk.Exception.Schemas.FaultDescription), XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FaultDescription' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Msft.Samples.BizTalk.Exception.Schemas.FaultSeverity), XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FaultSeverity' and namespace-uri()='']", XsdType = @"int")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Msft.Samples.BizTalk.Exception.Schemas.ServiceInstanceID), XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='ServiceInstanceID' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Msft.Samples.BizTalk.Exception.Schemas.ServiceName), XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='ServiceName' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Msft.Samples.BizTalk.Exception.Schemas.Description), XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='Description' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Msft.Samples.BizTalk.Exception.Schemas.ErrorType), XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='ErrorType' and namespace-uri()='']", XsdType = @"string")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Msft.Samples.BizTalk.Exception.Schemas.Scope), XPath = @"/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='Scope' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"FaultEnvelope"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Msft.Samples.BizTalk.Exception.Schemas.System_Properties", typeof(Msft.Samples.BizTalk.Exception.Schemas.System_Properties))]
    public sealed class FaultMessage : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:ns0=""http://Msft.Samples.BizTalk.Exception.Schemas/System-Properties"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://schemas.msft.samples.biztalk.com/exceptionmanagement"" targetNamespace=""http://schemas.msft.samples.biztalk.com/exceptionmanagement"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:imports>
        <b:namespace prefix=""ns0"" uri=""http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties"" location=""Msft.Samples.BizTalk.Exception.Schemas.System_Properties"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""FaultEnvelope"">
    <xs:annotation>
      <xs:appinfo>
        <b:recordInfo rootTypeName=""FaultEnvelope"" />
        <b:properties>
          <b:property distinguished=""true"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='Application' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FailureCategory' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FaultCode' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FaultDescription' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FaultSeverity' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='Scope' and namespace-uri()='']"" />
          <b:property name=""ns0:Application"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='Application' and namespace-uri()='']"" />
          <b:property name=""ns0:FailureCategory"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FailureCategory' and namespace-uri()='']"" />
          <b:property name=""ns0:FaultCode"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FaultCode' and namespace-uri()='']"" />
          <b:property name=""ns0:FaultDescription"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FaultDescription' and namespace-uri()='']"" />
          <b:property name=""ns0:FaultSeverity"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='FaultSeverity' and namespace-uri()='']"" />
          <b:property name=""ns0:ServiceInstanceID"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='ServiceInstanceID' and namespace-uri()='']"" />
          <b:property name=""ns0:ServiceName"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='ServiceName' and namespace-uri()='']"" />
          <b:property name=""ns0:Description"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='Description' and namespace-uri()='']"" />
          <b:property name=""ns0:ErrorType"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='ErrorType' and namespace-uri()='']"" />
          <b:property name=""ns0:Scope"" xpath=""/*[local-name()='FaultEnvelope' and namespace-uri()='http://schemas.msft.samples.biztalk.com/exceptionmanagement']/*[local-name()='Scope' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""Application"" type=""xs:string"" />
        <xs:element name=""Description"" type=""xs:string"" />
        <xs:element name=""ErrorType"" type=""xs:string"" />
        <xs:element name=""FailureCategory"" type=""xs:string"" />
        <xs:element name=""FaultCode"" type=""xs:string"" />
        <xs:element name=""FaultDescription"" type=""xs:string"" />
        <xs:element name=""FaultSeverity"" type=""xs:int"" />
        <xs:element name=""Scope"" type=""xs:string"" />
        <xs:element name=""ServiceInstanceID"" type=""xs:string"" />
        <xs:element name=""ServiceName"" type=""xs:string"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public FaultMessage() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "FaultEnvelope";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
