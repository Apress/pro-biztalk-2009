namespace Msft.Samples.BizTalk.Exception.Schemas {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Property)]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"Application", @"ContextProperties", @"Description", @"ErrorType", @"FailureCategory", @"FaultCode", @"FaultDescription", @"FaultSeverity", @"Scope", @"ServiceInstanceID", @"ServiceName", @"SystemException", @"MachineName", @"DateTime"})]
    public sealed class System_Properties : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties"" targetNamespace=""http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:schemaInfo schema_type=""property"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" />
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""Application"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""f8a6b5cf-d51b-48f5-935f-99022eb7434f"" propSchFieldBase=""MessageDataPropertyBase"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""ContextProperties"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""e60be9e4-e3a9-46fb-9862-830126843b79"" propSchFieldBase=""PartContextPropertyBase"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""Description"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""917e98f0-bfff-403e-b171-03ca5214a8fd"" propSchFieldBase=""MessageDataPropertyBase"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""ErrorType"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""c8395ffb-5be7-4e6d-9daa-2303a025c917"" propSchFieldBase=""MessageDataPropertyBase"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""FailureCategory"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""76b28de5-f11a-40b2-adab-261685064714"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""FaultCode"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""3b87d059-2974-4f5f-99fc-469c0dfdf63f"" propSchFieldBase=""MessageDataPropertyBase"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""FaultDescription"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""843e4072-420b-4852-b6ae-f1f66682ef85"" propSchFieldBase=""MessageDataPropertyBase"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""FaultSeverity"" type=""xs:int"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""17a90b17-fe5c-4f31-a5ff-ae1c7acf3d83"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""Scope"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""3f630dc0-30cd-4e08-8a98-36ae2dd1639b"" propSchFieldBase=""MessageDataPropertyBase"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""ServiceInstanceID"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""713aa03b-dc2a-415e-9ef5-7b83d4e72caa"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""ServiceName"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""20c686f3-88f6-4b35-90fd-67fae1b39893"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""SystemException"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""f178eb6c-6560-48cd-a837-fefe53b6ceba"" propSchFieldBase=""PartContextPropertyBase"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""MachineName"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""64143c75-34c7-492a-b993-c62c80a02ade"" propSchFieldBase=""MessageContextPropertyBase"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""DateTime"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""7d475bfd-2a5f-4ef2-958c-f32d4c9d951e"" propSchFieldBase=""MessageContextPropertyBase"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
</xs:schema>";
        
        public System_Properties() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [14];
                _RootElements[0] = "Application";
                _RootElements[1] = "ContextProperties";
                _RootElements[2] = "Description";
                _RootElements[3] = "ErrorType";
                _RootElements[4] = "FailureCategory";
                _RootElements[5] = "FaultCode";
                _RootElements[6] = "FaultDescription";
                _RootElements[7] = "FaultSeverity";
                _RootElements[8] = "Scope";
                _RootElements[9] = "ServiceInstanceID";
                _RootElements[10] = "ServiceName";
                _RootElements[11] = "SystemException";
                _RootElements[12] = "MachineName";
                _RootElements[13] = "DateTime";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"Application",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","string","System.String")]
    [PropertyGuidAttribute(@"f8a6b5cf-d51b-48f5-935f-99022eb7434f")]
    public sealed class Application : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"Application", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"ContextProperties",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","string","System.String")]
    [PropertyGuidAttribute(@"e60be9e4-e3a9-46fb-9862-830126843b79")]
    public sealed class ContextProperties : Microsoft.XLANGs.BaseTypes.PartContextPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"ContextProperties", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"Description",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","string","System.String")]
    [PropertyGuidAttribute(@"917e98f0-bfff-403e-b171-03ca5214a8fd")]
    public sealed class Description : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"Description", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"ErrorType",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","string","System.String")]
    [PropertyGuidAttribute(@"c8395ffb-5be7-4e6d-9daa-2303a025c917")]
    public sealed class ErrorType : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"ErrorType", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"FailureCategory",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","string","System.String")]
    [PropertyGuidAttribute(@"76b28de5-f11a-40b2-adab-261685064714")]
    public sealed class FailureCategory : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"FailureCategory", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"FaultCode",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","string","System.String")]
    [PropertyGuidAttribute(@"3b87d059-2974-4f5f-99fc-469c0dfdf63f")]
    public sealed class FaultCode : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"FaultCode", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"FaultDescription",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","string","System.String")]
    [PropertyGuidAttribute(@"843e4072-420b-4852-b6ae-f1f66682ef85")]
    public sealed class FaultDescription : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"FaultDescription", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"FaultSeverity",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","int","System.Int32")]
    [PropertyGuidAttribute(@"17a90b17-fe5c-4f31-a5ff-ae1c7acf3d83")]
    public sealed class FaultSeverity : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"FaultSeverity", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static int PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(int);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"Scope",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","string","System.String")]
    [PropertyGuidAttribute(@"3f630dc0-30cd-4e08-8a98-36ae2dd1639b")]
    public sealed class Scope : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"Scope", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"ServiceInstanceID",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","string","System.String")]
    [PropertyGuidAttribute(@"713aa03b-dc2a-415e-9ef5-7b83d4e72caa")]
    public sealed class ServiceInstanceID : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"ServiceInstanceID", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"ServiceName",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","string","System.String")]
    [PropertyGuidAttribute(@"20c686f3-88f6-4b35-90fd-67fae1b39893")]
    public sealed class ServiceName : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"ServiceName", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"SystemException",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","string","System.String")]
    [PropertyGuidAttribute(@"f178eb6c-6560-48cd-a837-fefe53b6ceba")]
    public sealed class SystemException : Microsoft.XLANGs.BaseTypes.PartContextPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"SystemException", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"MachineName",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","string","System.String")]
    [PropertyGuidAttribute(@"64143c75-34c7-492a-b993-c62c80a02ade")]
    public sealed class MachineName : Microsoft.XLANGs.BaseTypes.MessageContextPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"MachineName", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"DateTime",@"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties","string","System.String")]
    [PropertyGuidAttribute(@"7d475bfd-2a5f-4ef2-958c-f32d4c9d951e")]
    public sealed class DateTime : Microsoft.XLANGs.BaseTypes.MessageContextPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"DateTime", @"http://schemas.msft.samples.biztalk.com/exceptionmanagement/system-properties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
}
