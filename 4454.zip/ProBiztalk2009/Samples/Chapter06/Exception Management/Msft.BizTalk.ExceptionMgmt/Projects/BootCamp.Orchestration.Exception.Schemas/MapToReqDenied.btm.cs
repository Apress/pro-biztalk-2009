namespace BootCamp.Orchestration.Exception.Schemas {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"BootCamp.Orchestration.Exception.Schemas.Request", typeof(BootCamp.Orchestration.Exception.Schemas.Request))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"BootCamp.Orchestration.Exception.Schemas.RequestDenied", typeof(BootCamp.Orchestration.Exception.Schemas.RequestDenied))]
    public sealed class MapToReqDenied : Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp"" version=""1.0"" xmlns:ns0=""http://BootCamp.Orchestration.Exception.Schemas.RequestDenied"" xmlns:s0=""http:/BootCamp.Orchestration.Exception.Schemas.Request"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:Request"" />
  </xsl:template>
  <xsl:template match=""/s0:Request"">
    <xsl:variable name=""var:v1"" select=""userCSharp:MathMultiply(string(Item/Quantity/text()) , string(Item/UnitPrice/text()))"" />
    <ns0:DeclineReq>
      <ReqID>
        <xsl:value-of select=""$var:v1"" />
      </ReqID>
      <Qty>
        <xsl:value-of select=""Item/Quantity/text()"" />
      </Qty>
    </ns0:DeclineReq>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string MathMultiply(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 1;
	bool first = true;
	foreach (string obj in listValues)
	{
		double d = 0;
		if (IsNumeric(obj, ref d))
		{
			if (first)
			{
				first = false;
				ret = d;
			}
			else
			{
				ret *= d;
			}
		}
		else
		{
			return """";
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"BootCamp.Orchestration.Exception.Schemas.Request";
        
        private const string _strTrgSchemasList0 = @"BootCamp.Orchestration.Exception.Schemas.RequestDenied";
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"BootCamp.Orchestration.Exception.Schemas.Request";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"BootCamp.Orchestration.Exception.Schemas.RequestDenied";
                return _TrgSchemas;
            }
        }
    }
}
