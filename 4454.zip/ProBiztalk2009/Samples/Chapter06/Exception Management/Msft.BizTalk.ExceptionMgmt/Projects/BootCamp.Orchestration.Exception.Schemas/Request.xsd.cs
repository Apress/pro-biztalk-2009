namespace BootCamp.Orchestration.Exception.Schemas {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http:/BootCamp.Orchestration.Exception.Schemas.Request",@"Request")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.UInt32), "Item.Quantity", XPath = @"/*[local-name()='Request' and namespace-uri()='http:/BootCamp.Orchestration.Exception.Schemas.Request']/*[local-name()='Item' and namespace-uri()='']/*[local-name()='Quantity' and namespace-uri()='']", XsdType = @"unsignedInt")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(BootCamp.Orchestration.Exception.Schemas.Qty), XPath = @"/*[local-name()='Request' and namespace-uri()='http:/BootCamp.Orchestration.Exception.Schemas.Request']/*[local-name()='Item' and namespace-uri()='']/*[local-name()='Quantity' and namespace-uri()='']", XsdType = @"unsignedInt")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "Item.UnitPrice", XPath = @"/*[local-name()='Request' and namespace-uri()='http:/BootCamp.Orchestration.Exception.Schemas.Request']/*[local-name()='Item' and namespace-uri()='']/*[local-name()='UnitPrice' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"Request"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"BootCamp.Orchestration.Exception.Schemas.System_Properties", typeof(BootCamp.Orchestration.Exception.Schemas.System_Properties))]
    public sealed class Request : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:ns0=""http://BootCamp.Orchestration.Exception.Schemas/System-Properties"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http:/BootCamp.Orchestration.Exception.Schemas.Request"" targetNamespace=""http:/BootCamp.Orchestration.Exception.Schemas.Request"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:schemaInfo root_reference=""Request"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" />
      <b:imports>
        <b:namespace prefix=""ns0"" uri=""http://BootCamp.Orchestration.Exception.Schemas/System-Properties"" location=""BootCamp.Orchestration.Exception.Schemas.System_Properties"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""Request"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property distinguished=""true"" xpath=""/*[local-name()='Request' and namespace-uri()='http:/BootCamp.Orchestration.Exception.Schemas.Request']/*[local-name()='Item' and namespace-uri()='']/*[local-name()='Quantity' and namespace-uri()='']"" />
          <b:property name=""ns0:Qty"" xpath=""/*[local-name()='Request' and namespace-uri()='http:/BootCamp.Orchestration.Exception.Schemas.Request']/*[local-name()='Item' and namespace-uri()='']/*[local-name()='Quantity' and namespace-uri()='']"" />
          <b:property distinguished=""true"" xpath=""/*[local-name()='Request' and namespace-uri()='http:/BootCamp.Orchestration.Exception.Schemas.Request']/*[local-name()='Item' and namespace-uri()='']/*[local-name()='UnitPrice' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""Header"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""ReqID"" type=""xs:string"" />
              <xs:element name=""Date"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""Item"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""Description"" type=""xs:string"" />
              <xs:element name=""Quantity"" type=""xs:unsignedInt"" />
              <xs:element name=""UnitPrice"" type=""xs:string"" />
              <xs:element name=""TotalPrice"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Request() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "Request";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
