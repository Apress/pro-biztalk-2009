namespace BootCamp.Orchestration.Exception.Schemas {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://BootCamp.Orchestration.Exception.Schemas.RequestDenied",@"DeclineReq")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.UInt32), "Qty", XPath = @"/*[local-name()='DeclineReq' and namespace-uri()='http://BootCamp.Orchestration.Exception.Schemas.RequestDenied']/*[local-name()='Qty' and namespace-uri()='']", XsdType = @"unsignedInt")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"DeclineReq"})]
    public sealed class RequestDenied : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://BootCamp.Orchestration.Exception.Schemas.RequestDenied"" targetNamespace=""http://BootCamp.Orchestration.Exception.Schemas.RequestDenied"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""DeclineReq"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property distinguished=""true"" xpath=""/*[local-name()='DeclineReq' and namespace-uri()='http://BootCamp.Orchestration.Exception.Schemas.RequestDenied']/*[local-name()='Qty' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""ReqID"" type=""xs:string"" />
        <xs:element name=""Qty"" type=""xs:unsignedInt"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public RequestDenied() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "DeclineReq";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
